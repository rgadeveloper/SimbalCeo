/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ag.model.view;

/**
 *
 * @author 85154220
 */
public class DataRangosBalance {
    private String negativos;
    private String inconsistentes;
    private String bajo;
    private String medio;
    private String critico;
    private String sinBalance;

    /**
     * @return the negativos
     */
    public String getNegativos() {
        return negativos;
    }

    /**
     * @param negativos the negativos to set
     */
    public void setNegativos(String negativos) {
        this.negativos = negativos;
    }

    /**
     * @return the inconsistentes
     */
    public String getInconsistentes() {
        return inconsistentes;
    }

    /**
     * @param inconsistentes the inconsistentes to set
     */
    public void setInconsistentes(String inconsistentes) {
        this.inconsistentes = inconsistentes;
    }

    /**
     * @return the bajo
     */
    public String getBajo() {
        return bajo;
    }

    /**
     * @param bajo the bajo to set
     */
    public void setBajo(String bajo) {
        this.bajo = bajo;
    }

    /**
     * @return the medio
     */
    public String getMedio() {
        return medio;
    }

    /**
     * @param medio the medio to set
     */
    public void setMedio(String medio) {
        this.medio = medio;
    }

    /**
     * @return the critico
     */
    public String getCritico() {
        return critico;
    }

    /**
     * @param critico the critico to set
     */
    public void setCritico(String critico) {
        this.critico = critico;
    }

    /**
     * @return the sinBalance
     */
    public String getSinBalance() {
        return sinBalance;
    }

    /**
     * @param sinBalance the sinBalance to set
     */
    public void setSinBalance(String sinBalance) {
        this.sinBalance = sinBalance;
    }
    
    
}
