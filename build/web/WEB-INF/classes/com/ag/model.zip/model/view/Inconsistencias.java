/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ag.model.view;

import com.ag.model.Balances;
import com.ag.model.Componente;
import java.util.List;

/**
 *
 * @author arodriguezr
 */
public class Inconsistencias {
    private Componente trafo;   
    private Balances balance;

    public Inconsistencias() {
    }

    public Inconsistencias(Componente trafo, Balances balance) {
        this.trafo = trafo;
        this.balance = balance;
    }    

    public Componente getTrafo() {
        return trafo;
    }

    public void setTrafo(Componente trafo) {
        this.trafo = trafo;
    }

    public Balances getBalance() {
        return balance;
    }

    public void setBalance(Balances balance) {
        this.balance = balance;
    }
    
}
