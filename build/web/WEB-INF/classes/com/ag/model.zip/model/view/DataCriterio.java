/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ag.model.view;

/**
 *
 * @author 85154220
 */
public class DataCriterio {
    
    private String idVariable;
    private String nombreVariable;
    private String tipoOperador;
    private String nombreOperador;
    private String tipoOperadorLog;
    private String nombreOperadorLog;
    private String tipoFiltro;
    private String nombreFiltro;
    private String valor1;
    private String valor2;
    
    public DataCriterio(){}
    
    
    
}
